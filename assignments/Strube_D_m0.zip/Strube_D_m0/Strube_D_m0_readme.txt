David Alan Strube - dstrube3@gatech.edu
CS6457 - Video Game Design
Milestone 0

Main scene: MiniGame

Based off of this tutorial: https://learn.unity.com/project/roll-a-ball

Changes made from the tutorial:

1- Moved Count from the upper left to the upper right, and changed wording from "Count" to "Pickups remaining", and changed logic from count up to countdown.

2- Added my name to the upper left

3- Added inner walls. If player touches and inner wall before the game is over, then
	a- inner walls will shift to some other random location. (I was going to make them solid, but then figured the random positioning could trap the player; so instead they're meant to be a distraction obstacle)
	b- player does not get the extra reward when the game is over.

4- If player finishes the game without touching an inner wall, they are rewarded with confetti (Particle System).

5- Player's X & Z coordinates are shown in the lower left corner

6- I found that by running full speed into a wall, the player could slip past a wall and fall forever. So I added logic to reposition the player on the board if they manage to slip outside the walls. (I tried setting the coordinates to just (-)9.25, 0, z (or x, 0, (-)9.25), but the player would get still fall off the board sometimes. I figured out that setting y to 0.5 would be a good way to keep the player on the board.)

Any assignment requirements that have not been completed or don't work correctly: I'm not very satisfied with how direction change works / how responsive the controls are / how much momentum a player gathers. (As it is right now, it seems to take a lot of skill to navigate carefully.) Hopefully, learning more about game physics will help with this.

External assets: none

